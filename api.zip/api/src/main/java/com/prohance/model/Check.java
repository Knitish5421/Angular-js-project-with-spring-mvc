package com.prohance.model;

public class Check {

private String errormsg;

public String getErrormsg() {
	return errormsg;
}

public void setErrormsg(String errormsg) {
	this.errormsg = errormsg;
}

}

