app.controller("myappcontroller", function ($scope,$window, crudService){
	
	$scope.skills = {};
	getUserDetails();
	$scope.divAdd=false;
	
	 $scope.countries = {
             'India': {
                  'jharkhand': ['dhanbad', 'ranchi'],
                  'karnataka': ['bangalore', 'mysuru'],
                  'bihar': ['patna', 'gaya']
              }
          };

     $scope.stateList = $scope.countries.India;	 
         
	 $scope.addEmployee = function()
	 {
			 $scope.divAdd=true;
			 $scope.Action='Add';
			 $scope.id='';
			 $scope.firstname = '';
			 $scope.lastname ='';
			 $scope.gender ='';
			 $scope.age ='';
			 $scope.salary = '';
			 $scope.deptName = '';
			 $scope.city ='';
			 $scope.skills = { java: false, j2ee: false, js: false};
			 $scope.address='';
			 
		}
	 
	    $scope.editUser = function(user) {
	        $scope.divAdd=true;
		    $scope.Action='update';	   
	        $scope.id = user.id;
			$scope.firstname = user.firstname;
			$scope.lastname = user.lastname;
			$scope.gender = user.gender;
			$scope.age = user.age;
			$scope.salary = user.salary;
			$scope.deptName = user.deptName;
			$scope.state = user.state;
			$scope.city = user.city;
			$scope.skills = { java: user.skills.split(',').includes('java'), js: user.skills.split(',').includes('js'), j2ee: user.skills.split(',').includes('j2ee') };
			$scope.address = user.address;
			clearForm();
			editUser();
		}
	       
	       $scope.AddUpdateEmployee=function(){
	    	   var action=$scope.Action;
	    	   var user={
	    			   id : $scope.id,
	    			   firstname:$scope.firstname,
	    			   lastname :$scope.lastname,
	    			   gender :$scope.gender,
	    			   age : $scope.age,
	    			   salary : $scope.salary,
	    			   deptName : $scope.deptName,
	    			   state:$scope.state,
	    			   city:$scope.city,
	    			   skills:[],
	    			   address :$scope.address  
	    	   }
	    	   if($scope.skills.java) user.skills.push('java');
	    	   if($scope.skills.js) user.skills.push('js');
	    	   if($scope.skills.j2ee) user.skills.push('j2ee');
	    	   user.skills = user.skills.join(',');
	    	   if(action=='update'){
	    		   crudService.updateEmp(user).then(function(result){
	    			   clearForm();
	    			   getUserDetails();
	    		   },
	    		   function errorCallback(response) {
	    				console.log(response.data);
	    				alert("update process is fail due to same record is already  exist in the database");
	    			});
	    			   
	    	   }else
	    		   {
	    		   crudService.AddEmp(user).then(function(result){
	    			   clearForm();
	    			   
	    			   getUserDetails();
	    		   },
	    		   function errorCallback(response) {
	    				console.log(response.data);
	    				alert("registration process is fail due to same record is already  exist in the database");
	    			});
	    		   }
	    	   
	       }
	       $scope.deleteUser =function(id){
	    	  if($window.confirm("are you sure to delete?")){
	    	   crudService.DeleteEmp(id).then(function(result){
	    		   	alert("Success");
	    	   },function(){
	    		   getUserDetails();	   
	    	   })
	    	  }
	    	 
	       }
	       
	       function clearForm() {
	   		$scope.user.firstname = "";
	   		$scope.user.lastname = "";
	   		$scope.user.gender = "";
	   		$scope.user.age = "";
	   		$scope.user.salary = "";
	   		$scope.user.deptName = "";
	   		$scope.user.state = "";
	   		$scope.user.city = "";
	   		$scope.user.skills = "";
	   		$scope.user.address = "";
	   	};	       
	 
	   	function getUserDetails() {
			 crudService.getAll().then(function(result){
		     $scope.user=result.data;
			 },function(result){
				 console.log(result.data);
			 })     
		 }
})

