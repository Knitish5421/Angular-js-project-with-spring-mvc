

var app = angular.module('myapp', ['angularUtils.directives.dirPagination']);
