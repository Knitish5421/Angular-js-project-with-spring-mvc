app.service('crudService',function($http){

this.getAll = function () {
    return $http.get("rest/employees");
};

this.updateEmp = function (employee) {
    var response = $http({
        method: "post",
        url: "rest/update",
        data : angular.toJson(employee),
		headers : {
			'Content-Type' : 'application/json'
		}
    });
    return response;
}
this.AddEmp = function (employee) {
    var response = $http({
        method: "post",
        url: "rest/employee",
        data : angular.toJson(employee),
		headers : {
			'Content-Type' : 'application/json'
		}
    });
    return response;
}

this.DeleteEmp = function (id) {
    var response = $http({
        method: "DELETE",
        url:'rest/employee/' + id,
        headers : {
			'Content-Type' : 'application/json'
		}
    });
    return response;
}

})