



/*

    (function () {
        'use strict';
    angular.module('angApp', [])
    .controller('regController', function($scope, $http) {
    	$scope.users = []
    	$scope.userform = {
    			id : "",
    			firstname : "",
    			lastname : "",
    			gender : "",
    			age : "",
    			salary : "",
    			deptId : "",
    			state : "",
    			city : "",
    			skills : "",
    			address : "",
    	};
    	$scope.processUser = function() {
    		$http({
    			method : 'POST',
    			url : 'employee',
    			data : angular.toJson($scope.userform),
    			headers : {
    				'Content-Type' : 'application/json'
    			}
    		}).then(getUserDetails(), clearForm())

    	}

    	$scope.editUser = function(user) {
    		$scope.userform.firstname = user.firstname;
    		$scope.userform.lastname = user.lastname;
    		$scope.userform.gender = user.gender;
    		$scope.userform.age = user.age;
    		$scope.userform.salary = user.salary;
    		$scope.userform.deptId = user.deptId;
    		$scope.userform.state = user.state;
    		$scope.userform.city = user.city;
    		$scope.userform.skills = user.skills;
    		$scope.userform.address = user.address;
    		disableName();
    	}
    	function clearForm() {
    		$scope.userform.firstname = "";
    		$scope.userform.lastname = "";
    		$scope.userform.gender = "";
    		$scope.userform.age = "";
    		$scope.userform.salary = "";
    		$scope.userform.deptId = "";
    		$scope.userform.state = "";
    		$scope.userform.city = "";
    		$scope.userform.skills = "";
    		$scope.userform.address = "";
    		document.getElementById("name").disabled = false;
    	}
    	;
    	function disableName() {
    		document.getElementById("").disabled = true;
    	}	
    	
    });
    })();
*/