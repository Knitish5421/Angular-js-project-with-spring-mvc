
(function () {
    'use strict';
angular.module('angApp', [])
.controller('myappcontroller', function($scope, $http) {
	$scope.users = []
	var boolean = false;
	
	
	$scope.userform = {
			
			id : "",
			firstname : "",
			lastname : "",
			gender : "",
			age : "",
			salary : "",
			deptName : "",
			state : "",
			city : "",
			skills : "",
			address : "",
	};

	getUserDetails();

	function getUserDetails() {
		$http({
			method : 'GET',
			url : 'rest/employees'
		}).then(function successCallback(response) {
			
			console.log(response.data);
			$scope.users = response.data;
		}, function errorCallback(response) {
			console.log(response.data);
			alter(response.statusText);
		});
	}

$scope.processUser = function(emp) {

		if(boolean)
			{
			$http({
				method : 'POST',
				url : 'rest/update',
				data : angular.toJson($scope.userform),
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then( function (resp) {
				clearForm();
				boolean = false;
				$scope.statustext = response.statusText; 
				getUserDetails();
			})
			}
		else{
			$http({
				method : 'POST',
				url : 'rest/employee',
				data : angular.toJson($scope.userform),
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then( function (resp) {
				clearForm();
				getUserDetails();
			})
			

		}
	}

	$scope.editUser = function(user) {
		$scope.userform.firstname = user.firstname;
		$scope.userform.id = user.id;
		$scope.userform.lastname = user.lastname;
		$scope.userform.gender = user.gender;
		$scope.userform.age = user.age;
		$scope.userform.salary = user.salary;
		$scope.userform.deptName = user.deptName;
		$scope.userform.state = user.state;
		$scope.userform.city = user.city;
		$scope.userform.skills = user.skills;
		$scope.userform.address = user.address;
		boolean = true;
	}
	$scope.deleteUser = function(id) {
		 if (confirm("Are you sure to Delete this Information")){
		$http({
			method : 'DELETE',
			url : 'rest/employee/' + id,

			headers : {
				'Content-Type' : 'application/json'
			}
		}).then( function (resp) {
			getUserDetails();
		})
		
		 }
		 
	}
	function clearForm() {
		$scope.userform.firstname = "";
		$scope.userform.lastname = "";
		$scope.userform.gender = "";
		$scope.userform.age = "";
		$scope.userform.salary = "";
		$scope.userform.deptName = "";
		$scope.userform.state = "";
		$scope.userform.city = "";
		$scope.userform.skills = "";
		$scope.userform.address = "";
	};	
});


/*
app.controller('MainCtrl', function($scope) {
	  $scope.countries = {
	               'India': {
	                    'Maharashtra': ['Pune', 'Mumbai', 'Nagpur', 'Akola'],
	                    'Madhya Pradesh': ['Indore', 'Bhopal', 'Jabalpur'],
	                    'Rajasthan': ['Jaipur', 'Ajmer', 'Jodhpur']
	                }
	            };

	           $scope.stateList = $scope.countries.India;
	            $scope.GetSelectedState = function () {
	                $scope.strState = document.getElementById("state").value;
	            };

});

*/



})();