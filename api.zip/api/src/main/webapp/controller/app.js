
(function () {
    'use strict';

var app = angular.module('myapp', ["ngRoute","angApp"]);


app.controller('MainCtrl', function($scope) {
	  $scope.countries = {
	               'India': {
	                    'Jharkhand': ['Dhanbad', 'Ranchi'],
	                    'karnataka': ['Bangalore', 'Mysuru'],
	                    'Bihar': ['Patna', 'Gaya']
	                }
	            };

	           $scope.stateList = $scope.countries.India;
	           $scope.cityList;
	            $scope.GetSelectedState = function () {
	                $scope.strState = document.getElementById("state").value;
	                $scope.cityList =  $scope.stateList[$scope.userform.state];
	            };
	});

app.config(function($routeProvider) {
	  $routeProvider
	  .when("/register", {
	    templateUrl : "template/registration.html",
	    controller : "myappcontroller"	
	  })
	  .when("/view", {
		  templateUrl : "template/view.html"
	    })
	    .otherwise({
	    	redirectTo:"/"
	        
	    });  
	});
})();